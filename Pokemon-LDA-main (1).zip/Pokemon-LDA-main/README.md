# Pokemon-LDA
Linear Discriminant Analysis approach to Pokemon Dataset
